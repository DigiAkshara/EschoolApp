import React from 'react'

function ManageDailyTimeTable() {
  return <div>ManageDailyTimeTable</div>
}

export default ManageDailyTimeTable

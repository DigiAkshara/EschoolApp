import React from 'react'

function ManageCertificates() {
  return <div>ManageCertificates</div>
}

export default ManageCertificates

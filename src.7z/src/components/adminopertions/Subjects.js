import React from 'react'

function Subjects() {
  return (
    <div>Subjects</div>
  )
}

export default Subjects
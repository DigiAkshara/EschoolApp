import React from 'react'

function BreakTime() {
  return (
    <div>BreakTime</div>
  )
}

export default BreakTime